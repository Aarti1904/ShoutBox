<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee as EmployeeModel;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //ALL EMPLOYEE LIST
       
        $employeesList=EmployeeModel::all();

        return response()->json($employeesList,200);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
     /*    $this->validate(request(),[
             'name' => 'required',
             'email' => 'required',
             'dob' => 'required',
             'city' => 'required',
             'department' => 'required',

         ]);*/

        $newEmployee = new EmployeeModel;
 
         //echo ($request['name']);
        $newEmployee->name = $request->input('name');
        $newEmployee->email = $request->input('email');
        $newEmployee->dob = $request->input('dob');
        $newEmployee->city = $request->input('city');
        $newEmployee->department = $request->input('department');

        $newEmployee->save();
        
        return response()->json("Data stored!",200);



       
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $employeeData=EmployeeModel::find($id);
       
       if(is_null($employeeData)){
            return response('data not found',404);
        }
        else{
            return response()->json($employeeData,200);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       /* $this->validate(request(),[
            'name' => 'required',
            'email' => 'required',
            'dob' => 'required',
            'city' => 'required',
            'department' => 'required',

        ]);*/

       $update_Emp=EmployeeModel::find($id);
       
       if(is_null($update_Emp)){
        return response()->json('not found',404);
       }
        else{
        $update_Emp->name = $request->input('name');
        $update_Emp->email = $request->input('email');
        $update_Emp->dob = $request->input('dob');
        $update_Emp->city = $request->input('city');
        $update_Emp->department = $request->input('department');
 
        $update_Emp->save();
        return reponse()->json($update_Emp,200);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employee=EmployeeModel::find($id);

        if(is_null($employee))
        {
            return response()->json(["messege"=>"No Employee Found With Given ID"]);
        }

        $employee->delete();
        return response()->json(["messege"=>"Employee Deleted!!"],200);

    }
}
